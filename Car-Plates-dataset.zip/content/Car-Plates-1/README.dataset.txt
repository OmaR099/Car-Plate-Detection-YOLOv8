# Car Plates > 2024-09-30 12:47am
https://universe.roboflow.com/omar-workspace/car-plates-dizjh

Provided by a Roboflow user
License: CC BY 4.0

